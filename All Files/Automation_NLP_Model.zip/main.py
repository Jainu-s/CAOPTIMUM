import json

from rulbased_new import process_execution_steps
from functionalities import *
# from sample3 import keyword_processing
from remove_later import *
import re
import pandas as pd

# # Here is the nested list with keywords which is extracted from instructions
# instructions_list_2 = [['open', 'google', 'browser'], ['open', 'url'], ['click', 'CAMPUS POWER','option'],['click',"Start your journey",'add_text',"child’s financial needs"],['click','INSTITUTE','option'],
#                        ['click', 'Explore More', 'add_text', 'Stand-up Performances']]


# hCommon functionality keywords
dict_keys = ['click', 'press', 'open', 'hover', 'navigate', 'insert', 'enter', 'search', 'Open', 'Search', 'Click']

# Used in data preprocessing to remove
remove_words = ['option', 'menu', 'Button', 'button']

# browser list is mandatory.
browser_list = ['google browser', 'firefox browser', 'chrome browser', 'browser', 'Google Browser', 'Chrome Browser',
                'Browser']

import csv

# Open the CSV file
with open('Preprocessed.csv', 'r') as file:
    reader = csv.DictReader(file)
    data = list(reader)

# Convert the CSV data to a dataframe
csv_df = pd.DataFrame(data)

# Read the Excel file into a dataframe
excel_df = pd.read_excel('data.xlsx')

# Merge the dataframes based on index
combined_df = pd.concat([csv_df, excel_df], axis=1)

print('combined_df',combined_df)

# Perform actions based on predictions
driver = ''
# Loop over each row
for index, row in combined_df.iterrows():
    # if index >= 27:

    # Store column values in variables
    text = str(row['Text']) + ' ' + str(row['Data'])
    prediction = row['Prediction']
    url = row['Data']



    # Example: Print the column values
    print(f"Text: {text}")
    print(f"Prediction: {prediction}")
    print(f"URL: {url}")
    print("-" * 20)

    if prediction == 'browser':
        print('Browser Triggered')
        driver = browser_function()

    if prediction == 'url':
        print('Url triggered')
        url_function(driver, url)

    if prediction == 'search':
        print('search triggered')
        browser_search_function(driver,url,text)

    if prediction == 'click':
        print('click triggered')
        click_function(driver,url,text)

    if prediction == 'insert':
        print('insert/enter triggered')
        insert_function(driver,url,text)

    if prediction == 'hover':
        print('hover triggered')
        hover_function(driver,url,text)


