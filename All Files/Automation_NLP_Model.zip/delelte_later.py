# from selenium import webdriver
# from selenium.webdriver.chrome.service import Service
# from selenium.webdriver.common.by import By
# from bs4 import BeautifulSoup
#
# # Set the path to your ChromeDriver executable
# chrome_driver_path = 'chrome webdriver/chromedriver.exe'
#
# # Set up the Selenium service
# selenium_service = Service(chrome_driver_path)
#
# # Set up the Selenium driver
# driver = webdriver.Chrome(service=selenium_service)
#
# # Load the URL
# url = 'https://www.godaddy.com/'  # Replace with your desired URL
# driver.get(url)
#
# # Wait for the page to load completely (optional)
# driver.implicitly_wait(10)  # Adjust the wait time as needed
#
# # Get the page source code
# html_code = driver.page_source
#
# # Close the Selenium WebDriver
# driver.quit()
#
# # Create a BeautifulSoup object
# soup = BeautifulSoup(html_code, 'html.parser')
#
# # Prettify the code
# beautified_code = soup.prettify()
#
# # Find all input and textarea tags
# input_tags = soup.find_all(['input', 'textarea'])
#
# # Retrieve attributes of each tag
# for tag in input_tags:
#     tag_name = tag.name
#     attributes = tag.attrs
#     print(f"Tag Name: {tag_name}")
#     print("Attributes:")
#     for attr in attributes:
#         print(f"  - {attr}: {attributes[attr]}")
#     print()


from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
from fuzzywuzzy import fuzz
from fuzzywuzzy import fuzz
from fuzzywuzzy import process

def find_input_textarea(html_code,sentence,double_quoted_word):

    print('--------------------------------------------------')
    print('words:',sentence)
    # # Set the path to your ChromeDriver executable
    # chrome_driver_path = '/path/to/chromedriver'
    #
    # # Set up the Selenium service
    # selenium_service = Service(chrome_driver_path)
    #
    # # Set up the Selenium driver
    # driver = webdriver.Chrome(service=selenium_service)
    #
    # # Load the URL
    # url = 'https://www.signupgenius.com/index.cfm?go=w.Welcome&prior=w.createSignUp&formName=registerForm'  # Replace with your desired URL
    # driver.get(url)
    #
    # # Wait for the page to load completely (optional)
    # driver.implicitly_wait(10)  # Adjust the wait time as needed
    #
    # # Get the page source code
    # html_code = driver.page_source
    #
    # # Close the Selenium WebDriver
    # driver.quit()

    # Create a BeautifulSoup object
    soup = BeautifulSoup(html_code, 'html.parser')

    # Find all input and textarea tags
    input_tags = soup.find_all(['input', 'textarea','select'])



    # Loop over tags and print attribute values if they exist
    # for tag in input_tags:
    #     print('tag.attr',tag.attrs)
    #     tag_name = tag.name
    #     print('tag_name:',tag_name)
    #
    #     # id = ''
    #     # name = ''
    #     # type = ''
    #     # class_name = ''
    #     # place_holder = ''
    #     # value = ''
    #     #
    #     all_attr_list = []
    #     #
    #     # # Check if attribute exists before accessing its value
    #     # if 'id' in tag.attrs:
    #     #     tag_id = tag.attrs['id']
    #     #     id = tag_id
    #     #     all_attr_list.append(id)
    #     # else:
    #     #     tag_id = None
    #     #     id = tag_id
    #     #     all_attr_list.append(id)
    #     #
    #     #
    #     # if 'name' in tag.attrs:
    #     #     tag_name_attr = tag.attrs['name']
    #     #     name = tag_name_attr
    #     #     all_attr_list.append(name)
    #     # else:
    #     #     tag_name_attr = None
    #     #     name = tag_name_attr
    #     #     all_attr_list.append(name)
    #     #
    #     # if 'type' in tag.attrs:
    #     #     tag_type = tag.attrs['type']
    #     #     type = tag_type
    #     #     all_attr_list.append(type)
    #     #
    #     # else:
    #     #     tag_type = None
    #     #     type = tag_type
    #     #     all_attr_list.append(type)
    #     #
    #     # if 'class' in tag.attrs:
    #     #     tag_class = tag.attrs['class']
    #     #     class_name = tag_class
    #     #     all_attr_list.append(class_name)
    #     # else:
    #     #     tag_class = None
    #     #     class_name = tag_class
    #     #     all_attr_list.append(class_name)
    #     #
    #     # if 'placeholder' in tag.attrs:
    #     #     tag_placeholder = tag.attrs['placeholder']
    #     #     place_holder = tag_placeholder
    #     #     all_attr_list.append(place_holder)
    #     # else:
    #     #     tag_placeholder = None
    #     #     place_holder = tag_placeholder
    #     #     all_attr_list.append(place_holder)
    #     #
    #     # if 'value' in tag.attrs:
    #     #     tag_value = tag.attrs['value']
    #     #     value = tag_value
    #     #     all_attr_list.append(value)
    #     # else:
    #     #     tag_value = None
    #     #     value = tag_value
    #     #     all_attr_list.append(value)
    #
    #     # Print the attribute values
    #     # print(f"Tag Name: {tag_name}")
    #     # print(f"ID: {tag_id}")
    #     # print(f"Name: {tag_name_attr}")
    #     # print(f"Type: {tag_type}")
    #     # print(f"Class: {tag_class}")
    #     # print(f"Placeholder: {tag_placeholder}")
    #     # print(f"Value: {tag_value}")
    #     # print()
    #
    #     import re
    #     from fuzzywuzzy import fuzz
    #
    #
    #     words = re.sub(r'"[^"]*"', '', sentence)
    #     # for attr in all_attr_list:
    #     #     if isinstance(attr, str):
    #     #         print('attr:',attr,'words:',words,)
    #     #         fuzzy_ratio = fuzz.token_set_ratio(attr, words)
    #     #         print(f"Fuzzy match between '{attr}' and '{words}': {fuzzy_ratio}")
    #     #         if fuzzy_ratio > 70:
    #     #             return all_attr_list
    #
    #     # Match each value in the tag attributes with the search sentence using fuzzy token set ratio
    all_attr_list = []
    for each_tag in input_tags:
        print('double quoted word:', double_quoted_word)
        print('tag:',each_tag)

        for key, value in each_tag.attrs.items():
            print('key:',key,',','value:',value)
            for word in sentence.split():
                if value is not None:
                    if value != double_quoted_word.replace('"', ''):
                        print('value:',value,'value type:',type(value),'sentence:',sentence,'sentence type:',type(sentence))
                        att_score = fuzz.token_set_ratio(str(value),sentence)
                        sent_score = fuzz.token_set_ratio(word,value)
                        if att_score > sent_score and att_score > 70:
                            all_attr_list.append([key,value,att_score])
                        elif sent_score > att_score and  sent_score > 70:
                            all_attr_list.append([key,value, sent_score])
                        elif word in value:

                            found_sublists = [sublist for sublist in all_attr_list if [key,value] == sublist[:2]]
                            if not found_sublists:
                                print('word in value executed')
                                print('word:',word,',','value:',value)
                                print('all_attr_list:',all_attr_list)
                                all_attr_list.append([key,value])
                                return key,value
                            except:
                                pass
                            else:
                                return key,value

                    elif value == double_quoted_word.replace('"', ''):
                        value = ''
                        print('key here---------:',key,'value here-------------:',value)
                        return key,value

                    print('word:',word,',','value:',value,',','double quoted word:',double_quoted_word)



    print('all_attr_list:',all_attr_list)

    if all_attr_list:
        max_sublist = max(all_attr_list, key=lambda x: x[2])
        max_key, max_value, max_number = max_sublist
        print(max_key, max_value, max_number)
        if max_value == 'password' or 'Password':
            return max_key, max_value
    else:
        print("The list is empty.")
        return None,None

        # print('all_attr_list:',all_attr_list)




