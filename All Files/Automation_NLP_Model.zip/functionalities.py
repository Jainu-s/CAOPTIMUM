import math
import time
import re
from lxml import etree, html
from delelte_later import find_input_textarea
import getxpath
import requests
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from rapidfuzz import process, fuzz
from xpath_identifier import generate_xpath


def browser_function():
    print('Browser Functionality Triggered')
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument(
        "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.9999.99 Safari/537.36")

    chrome_options.add_argument("--disable-notifications")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--enable-javascript")
    prefs = {"profile.default_content_setting_values.notifications": 2}
    chrome_options.add_experimental_option("prefs", prefs)
    driver = webdriver.Chrome(chrome_options=chrome_options)
    # Store the initial window handle (current tab)
    initial_window_handle = driver.current_window_handle
    return driver


def url_function(driver, url):

    print('driver:', driver, 'url:', url)
    print('URL Functionality Triggered')
    driver.get(url)
    time.sleep(5)




def browser_search_function(driver,url,key):

    driver.get('https://www.google.co.in')
    wait = WebDriverWait(driver, 10)  # Maximum wait time of 10 seconds
    search_box = wait.until(EC.presence_of_element_located((By.XPATH, "//*[@id='APjFqb']")))
    search_box.click()
    search_box.send_keys(url)
    search_button = wait.until(EC.element_to_be_clickable((By.NAME, "btnK")))
    search_button.click()
    time.sleep(5)


def click_function(driver,clickable_url,keyword):
    global double_quoted_word
    print('click functionality triggered')

    print('keyword in the begin:',keyword)

    # Search for "add_text" within double quotes
    match = re.search(r'"([^"]*add_text[^"]*)"', keyword)
    keyword = keyword
    # If a match is found, remove the double quotes from the matched group
    if match:
        keyword = keyword.replace(match.group(0), match.group(1).replace('"', ''))
        print('keyword:', keyword)

    # Extract the double-quoted string using regular expressions
    double_quotes_match = re.search(r'"([^"]+)"', keyword)
    double_quoted_keyword = ''
    if double_quotes_match:
        double_quoted_word = double_quotes_match.group(1)
        double_quoted_keyword = double_quoted_word
    try:
        # Simulate pressing the Escape key
        body_element = driver.find_element("tag name", "body")
        body_element.send_keys(Keys.ESCAPE)
    except:
        pass

    html_code = driver.page_source
    prettified_html = pretty_code(html_code)


    # Check if a new tab has been opened
    if len(driver.window_handles) > 1:
        # Switch to the new tab
        driver.switch_to.window(driver.window_handles[1])

    # Additional information to determine which element to click
    # Check if the instruction string contains 'add_text'
    if 'add_text' in keyword:
        print('add_text is available in the keyword')
        # Split the string into left and right parts, excluding 'add_text'
        parts = keyword.split('add_text')
        keyword = parts[0].strip()
        keyword = keyword.replace('"','')
        additional_info = parts[1].strip()
    else:
        keyword = keyword
        additional_info = None



    # Construct the XPath query to find the desired element based on the additional information

    if additional_info:
        print('Double Quoted Keyword:', double_quoted_keyword, '&', 'additional info:', additional_info)
        original_xpath = find_element(prettified_html, double_quoted_keyword, additional_info)
        print('full_Xpath: ', original_xpath)
        final_xpath = mod_xpath(original_xpath)
        print('final_xpath:', final_xpath)

        for i in final_xpath:
            print('Triggered this i')
            try:
                # Wait for the keyword element to appear
                WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.XPATH, i))).click()
            except:
                pass

        # Print success message
        print("Program executed successfully.")
        # Sleep
        time.sleep(5)

    elif 'official link' in keyword or 'original link' in keyword or 'link' in keyword:
        print('This official link block is executed')
        url = clickable_url
        # Wait for the search results to appear
        wait = WebDriverWait(driver, 10)
        search_results = wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div.g")))
        from urllib.parse import urlparse

        def extract_domain(url):
            parsed_url = urlparse(url)
            domain = parsed_url.netloc
            return domain

        domain = extract_domain(url)
        print('domain', domain)
        # Find and click the first link that corresponds to Flipkart
        for result in search_results:
            link = result.find_element(By.XPATH, ".//a")
            if domain in link.get_attribute("href"):
                link.click()
                break
    else:

        print('double quoted keyword in else:',double_quoted_keyword)
        original_xpath = find_element(prettified_html, double_quoted_keyword, None)
        # print('original_xpath: ', original_xpath)
        final_xpath = mod_xpath(original_xpath)
        print('final_xpath:', final_xpath)

        for i in final_xpath:
            print('Triggered i 2')
            try:
                # Wait for the keyword element to appear
                WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.XPATH, i))).click()
            except:
                try:
                    element = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.XPATH, f"//*[contains(text(),{double_quoted_keyword})]")))
                    element.click()
                except:
                    # Get the page source
                    page_source = driver.page_source

                    # Beautify the HTML code
                    soup = BeautifulSoup(page_source, 'html.parser')
                    formatted_html = soup.prettify()

                    # Save the formatted HTML code to a file
                    with open('formatted_html.html', 'w', encoding='utf-8') as file:
                        file.write(formatted_html)

                    # Extract all clickable elements
                    clickable_elements = soup.find_all('a')  # Modify this to include other element types if needed

                    new_list = []
                    for each_element in clickable_elements:
                        print('each_elemenr:', each_element.attrs)
                        for key, value in each_element.attrs.items():
                            print('key:',key,'value:',value)
                            for word in double_quoted_word.split():
                                print('double quoted word:',word)
                                att_score = fuzz.token_set_ratio(str(word), value)
                                dtt_score = fuzz.token_set_ratio(value,double_quoted_word)
                                new_att_score = ''
                                new_dtt_score = ''
                                if att_score > dtt_score:
                                    print('att score:',att_score,'key:',key,'value:',value)
                                    new_att_score = 1

                                elif dtt_score > att_score:
                                    print('dtt score:',dtt_score,'key:',key,'value:',value)
                                    new_dtt_score = 1



                                    element = ''
                                    key_name = key
                                    value_name = value
                                    # Define the wait time in seconds
                                    wait = WebDriverWait(driver, 10)
                                    # Wait until the element with the specified ID is clickable
                                    if key_name == 'id':
                                        try:
                                            element = wait.until(EC.element_to_be_clickable((By.ID, value_name)))
                                            print('ID Executed')
                                        except:
                                            pass

                                    elif key_name == 'name':
                                        try:
                                            element = wait.until(EC.element_to_be_clickable((By.NAME, value_name)))
                                            print('Name Executed')
                                        except:
                                            pass
                                    elif key_name == 'type':
                                        try:
                                            element = wait.until(EC.presence_of_element_located(
                                                (By.CSS_SELECTOR, f"[type={value_name}]")))
                                            print('Type Executed')
                                        except:
                                            pass
                                    elif key_name == 'class':
                                        try:
                                            element = wait.until(
                                                EC.element_to_be_clickable((By.CLASS_NAME, value_name)))
                                            print('class name Executed')
                                        except:
                                            pass
                                    elif key_name == 'placeholder':
                                        try:
                                            element = wait.until(EC.element_to_be_clickable(
                                                (By.CSS_SELECTOR, f"[placeholder='{value_name}']")))
                                            print('place holder executed')
                                        except:
                                            pass
                                    elif key_name == 'value':
                                        try:
                                            element = wait.until(EC.element_to_be_clickable(
                                                (By.CSS_SELECTOR, f"[value='{value_name}']")))
                                            print('value executed')
                                        except:
                                            pass
                                    else:
                                        try:
                                            element = wait.until(EC.presence_of_element_located(
                                                (By.CSS_SELECTOR, f"[{key_name}='{value_name}']")))
                                            print(f"{key_name} executed")
                                        except:
                                            pass

                                    try:
                                        element.click()
                                        # element.send_keys(double_quoted_keyword)
                                        # # element.send_keys(Keys.RETURN)
                                    except:
                                        print('send keys not working')

                    # Process and interact with the extracted clickable elements as needed
                    for element in clickable_elements:
                        print('element:',element)
                        href = element.get('href')
                        text = element.text
                        print(f"Clickable Element - Text: {text}, Href: {href}")

            time.sleep(5)

            # Print success message
            print("Program executed successfully.")
            # Sleep
            time.sleep(5)


last_tag_value = []
def insert_function(driver,url,keyword):
    # Check if a new tab has been opened
    if len(driver.window_handles) > 1:
        # Switch to the new tab
        driver.switch_to.window(driver.window_handles[1])
    print('Insert Functionality Triggered')

    # Search for "add_text" within double quotes
    match = re.search(r'"([^"]*add_text[^"]*)"', keyword)
    keyword = keyword
    # If a match is found, remove the double quotes from the matched group
    if match:
        keyword = keyword.replace(match.group(0), match.group(1).replace('"', ''))
        print('keyword:', keyword)

    # Extract the double-quoted string using regular expressions
    double_quotes_match = re.search(r'"([^"]+)"', keyword)
    double_quoted_keyword = ''
    if double_quotes_match:
        double_quoted_word = double_quotes_match.group(1)
        double_quoted_keyword = double_quoted_word
    try:
        # Simulate pressing the Escape key
        body_element = driver.find_element("tag name", "body")
        body_element.send_keys(Keys.ESCAPE)
    except:
        pass



    current_url = driver.current_url
    print(current_url)
    html_code = driver.page_source

    #id, name, type, class_name, place_holder, value = find_input_textarea(html_code, keyword)
    key_name, value_name = find_input_textarea(html_code, keyword, double_quoted_keyword)
    last_tag_value.append(key_name)
    last_tag_value.append(value_name)
    print('key_name:',key_name , 'value_name:',value_name)
    # Define the wait time in seconds
    wait = WebDriverWait(driver, 10)
    element = ''
    # Wait until the element with the specified ID is clickable
    if key_name == 'id':
        try:
            element = wait.until(EC.element_to_be_clickable((By.ID, value_name)))
            print('ID Executed')
        except:
            pass

    elif key_name == 'name':
        try:
            element = wait.until(EC.element_to_be_clickable((By.NAME, value_name)))
            print('Name Executed')
        except:
            pass
    elif key_name == 'type':
        try:
            element = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR,f"[type={value_name}]")))
            print('Type Executed')
        except:
            pass
    elif key_name == 'class':
        try:
            element = wait.until(EC.element_to_be_clickable((By.CLASS_NAME, value_name)))
            print('class name Executed')
        except:
            pass
    elif key_name == 'placeholder':
        try:
            element = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, f"[placeholder='{value_name}']")))
            print('place holder executed')
        except:
            pass
    elif key_name == 'value':
        try:
            element = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, f"[value='{value_name}']")))
            print('value executed')
        except:
            pass
    else:
        try:
            element = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, f"[{key_name}='{value_name}']")))
            print(f"{key_name} executed")
        except:
            pass

    try:
        element.click()
        element.send_keys(double_quoted_keyword)
        # element.send_keys(Keys.RETURN)
    except:
        print('send keys not working')






def hover_function(driver,url,keyword):
    # Check if a new tab has been opened
    if len(driver.window_handles) > 1:
        # Switch to the new tab
        driver.switch_to.window(driver.window_handles[1])

    try:
        # Simulate pressing the Escape key
        body_element = driver.find_element("tag name", "body")
        body_element.send_keys(Keys.ESCAPE)
    except:
        pass

    keyword = keyword.replace('"','')
    print('keyword:', keyword)
    print('Hover Functionality Triggered')
    url = driver.current_url
    html_code = driver.page_source
    prettified_html = pretty_code(html_code)
    original_xpath = find_element(prettified_html, str(keyword).strip(), None)

    # original_xpath = find_element(prettified_html,keyword,None)
    print('full_Xpath: ', original_xpath)
    final_xpath = mod_xpath(original_xpath)
    print('final_xpath:', final_xpath)

    for i in final_xpath:
        try:
            # Wait for the keyword element to appear
            dropdown = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, i)))


            # Create an instance of ActionChains
            actions = ActionChains(driver)

            # Move the mouse cursor to the element to hover over it
            actions.move_to_element(dropdown).perform()

            time.sleep(5)
        except:
            pass


    # # Continue with other actions after hovering
    # # For example, you can click on a sub-element of the hovered element
    # sub_element = driver.find_element_by_xpath("sub_element_xpath")
    # actions.move_to_element(sub_element).click().perform()


def keyword_variation(string):
    string = string.strip()
    lowercase_string = string.lower()
    variations = [
        lowercase_string,
        lowercase_string.title(),
        lowercase_string.capitalize(),
        string.upper()
    ]

    # Generate variations with "sign-in" if the string contains a space
    if ' ' in string:
        variations += [
            string.replace(' ', '-'),
            string.replace(' ', '-').title(),
            string.replace(' ', '-').capitalize(),
            string.replace(' ', '-').upper()
        ]

    elif string == 'username':
        variations += [
            'user-name', 'User-name', 'User-Name', 'user_name', 'User_name', 'User_Name']
    elif string == 'password':
        variations += [
            'pass-word', 'Pass-word', 'Pass-Word', 'pass_word', 'Pass_word', 'Pass_word']

    return variations


from bs4 import BeautifulSoup


def process_xpath(xpath):
    # Remove "/None[1]" from the xpath
    xpath = xpath.replace("/None[1]", "")

    # Remove the indexing "[1]" from each element except the last one
    xpath_parts = xpath.split('/')
    xpath_parts = [part.split('[')[0] for part in xpath_parts[:-1]]

    # Add back the indexing for the last element if it is not empty
    last_part = xpath_parts[-1].split('[')[0]
    if last_part:
        xpath_parts[-1] = last_part

    # Reconstruct the modified xpath
    modified_xpath = '/'.join(xpath_parts)

    return modified_xpath


# def find_element(html_code, target, sub_text=None):
#     soup = BeautifulSoup(html_code, 'html.parser')
#     target_elements = soup.find_all(text=lambda text: target in text.strip())
#
#     if not target_elements:
#         return ["Element not found."]
#
#     paths = []
#     for target_element in target_elements:
#         path = []
#         current = target_element
#         while current.parent:
#             tag = current.name
#             index = sum(1 for sibling in current.previous_siblings if sibling.name == tag) + 1
#             path.insert(0, f"{tag}[{index}]")
#             current = current.parent
#
#         if sub_text:
#             div_element = target_element.find_parent('div')
#             if div_element:
#                 parent_div_element = div_element.find_parent('div')
#                 if parent_div_element and sub_text in parent_div_element.get_text():
#                     paths.append(path)
#             else:
#                 direct_parent_div = target_element.find_parent('div')
#                 if direct_parent_div and sub_text in direct_parent_div.get_text():
#                     paths.append(path)
#         else:
#             paths.append(path)
#
#     if not paths:
#         return ["Element not found."]
#
#     return paths

def find_element(html_code, target, sub_text=None):
    soup = BeautifulSoup(html_code, 'html.parser')
    target_elements = soup.find_all(text=lambda text: target in text.strip())

    if not target_elements:
        return ["Element not found."]

    paths = []
    for target_element in target_elements:
        path = []
        current = target_element
        while current.parent:
            tag = current.name
            index = sum(1 for sibling in current.previous_siblings if sibling.name == tag) + 1
            path.insert(0, f"{tag}[{index}]")
            current = current.parent

        if sub_text:
            div_element = target_element.find_parent('div')
            if div_element:
                parent_div_element = div_element.find_parent('div')
                if parent_div_element and sub_text in parent_div_element.get_text():
                    paths.append(path)
            else:
                direct_parent_div = target_element.find_parent('div')
                if direct_parent_div and sub_text in direct_parent_div.get_text():
                    paths.append(path)
        else:
            paths.append(path)

    if not paths:
        return ["Element not found."]

    return paths





def mod_xpath(output):
    results = []
    for i in output:
        print('i:', i)
        # Remove '[1]' only if it appears at the end of each element
        x = [element.replace('[1]', '') if element.endswith('[1]') else element for element in i]

        # Remove 'None' element from the list
        x = [element for element in x if element != 'None']

        result = "/".join(x)
        results.append(result)
    return results


def pretty_code(html_code):
    import requests
    from bs4 import BeautifulSoup

    # # Send a GET request to the URL
    # response = requests.get(url)
    #
    # # Get the HTML content from the response
    # html_content = response.text

    # Create a BeautifulSoup object to parse the HTML
    soup = BeautifulSoup(html_code, "html.parser")

    # Prettify the HTML code
    prettified_html = soup.prettify()

    return prettified_html
