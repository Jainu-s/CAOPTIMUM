a = 5
b = 3
result = a + b
print(result)
