# import os
# import matplotlib.pyplot as plt
#
# def is_folder_empty(folder_path):
#     return not os.listdir(folder_path)
#
# def traverse_folders(base_folder):
#     results = {"Passed": 0, "Failed": 0}
#     for root, _, files in os.walk(base_folder):
#         if is_folder_empty(root):
#             results["Passed"] += 1
#         else:
#             results["Failed"] += 1
#     return results
#
# def create_dashboard(data):
#     labels = list(data.keys())
#     values = list(data.values())
#
#     plt.bar(labels, values, color=['green', 'red'])
#     plt.xlabel('Test Results')
#     plt.ylabel('Number of Folders')
#     plt.title('Test Case Results')
#     plt.show()
#
# def visualization():
#     base_folder = "Screenshot"  # Replace with the path to your folder
#     test_results = traverse_folders(base_folder)
#     create_dashboard(test_results)
#
# print(visualization())
#

import os
import matplotlib.pyplot as plt

# Base path
base_path = "Screenshot"

# Initialize counters
total_cases = 0
failed_cases = 0

# Iterate over each directory in the base path
for directory in os.listdir(base_path):
    dir_path = os.path.join(base_path, directory)
    # Check if it is a directory
    if os.path.isdir(dir_path):
        total_cases += 1
        # Iterate over each file in the directory
        for file in os.listdir(dir_path):
            # Check if it is an image file
            if file.endswith(".png") or file.endswith(".jpg"): # add more formats if needed
                failed_cases += 1
                break

# Now we have the total_cases and failed_cases, we can plot a simple bar chart

# X-axis values (categories)
categories = ['Total Cases', 'Failed Cases']

# Corresponding Y-axis values (counts)
counts = [total_cases, failed_cases]

# Creating the bar plot
plt.bar(categories, counts, color ='maroon', width = 0.4)

plt.show()


