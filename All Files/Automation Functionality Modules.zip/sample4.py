import getxpath

a = getxpath.findxpath("https://www.icicibank.com/","CAMPUS POWER")
print('a:',a)
# //*[@id="rf01"]/header/div[2]/div/div/nav/ul/li[6]/a/span
